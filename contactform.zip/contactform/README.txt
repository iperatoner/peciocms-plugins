Instructions:
-------------
1. Upload the folder with all its content to ./pec_plugins/
2. Set the permission of the directory "contactform" to 777, not recursive
3. Log into the cms.
4. Finshed.